<?php
    header("location:pages/Demande.php");
?>
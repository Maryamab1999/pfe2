<?php
    require_once('identifier.php');
    require_once('connexiondb.php');
    $nom=isset($_POST['nom'])?$_POST['nom']:"";
    $prenom=isset($_POST['prenom'])?$_POST['prenom']:"";
    $civilite=isset($_POST['civilite'])?$_POST['civilite']:"F";
    $iddemande=isset($_POST['iddemande'])?$_POST['iddemande']:1;

   

    $requete="insert into Etudiant(nom,prenom,civilite,iddemande) values(?,?,?,?)";
    $params=array($nom,$prenom,$civilite,$iddemande);
    $resultat=$pdo->prepare($requete);
    $resultat->execute($params);
    
    header('location:Etudiant.php');

?>
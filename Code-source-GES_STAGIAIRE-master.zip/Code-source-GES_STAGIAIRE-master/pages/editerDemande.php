<?php
   require_once('identifier.php');
    require_once('connexiondb.php');
    $idD=isset($_GET['idD'])?$_GET['idD']:0;
    $requete="select * from Demande where iddemande=$idD";
    $resultat=$pdo->query($requete);
    $Demande=$resultat->fetch();
    $nomD=$Demande['nomDemande'];
    $niveau=strtolower($Demande['niveau']);
?>
<! DOCTYPE HTML>
<HTML>
    <head>
        <meta charset="utf-8">
        <title>Edition d'une demande</title>
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    </head>
    <body>
        <?php include("menu.php"); ?>
        
        <div class="container">
                       
             <div class="panel panel-primary margetop60">
                <div class="panel-heading">Edition de demande :</div>
                <div class="panel-body">
                    <form method="post" action="updateDemande.php" class="form">
						<div class="form-group">
                             <label for="niveau">id de demande: <?php echo $idD ?></label>
                            <input type="hidden" name="idD" 
                                   class="form-control"
                                    value="<?php echo $idD ?>"/>
                        </div>
                        
                        <div class="form-group">
                             <label for="niveau">Nom de demande:</label>
                               <select name="niveau" class="form-control" id="niveau">
                                <option value="RV" <?php if($niveau=="s1") echo "selected" ?>>Relevé des notes</option>
                                <option value="At" <?php if($niveau=="s2") echo "selected" ?>>Attestation</option>
                            <option value="DP" <?php if($niveau=="s2") echo "selected" ?>>Diplôme</option>
</select>
                        </div>
                        
                        <div class="form-group">
                            <label for="niveau">Niveau:</label>
				            <select name="niveau" class="form-control" id="niveau">
                                <option value="s1" <?php if($niveau=="s1") echo "selected" ?>>Semestre1</option>
                                <option value="s2" <?php if($niveau=="s2") echo "selected" ?>>Semestre2</option>
                                <option value="s3"<?php if($niveau=="s3") echo "selected" ?>>Semestre3</option>
                                <option value="s4" <?php if($niveau=="s4") echo "selected" ?>>Semestre4</option>
                                <option value="s5" <?php if($niveau=="s4") echo "selected" ?>>Semestre5</option>
                                <option value="s6" <?php if($niveau=="s6") echo "selected" ?>>Semestre6</option> 
				            </select>
                        </div>
                        
				        <button type="submit" class="btn btn-success">
                            <span class="glyphicon glyphicon-save"></span>
                            Enregistrer
                        </button> 
                      
					</form>
                </div>
            </div>   
        </div>      
    </body>
</HTML>
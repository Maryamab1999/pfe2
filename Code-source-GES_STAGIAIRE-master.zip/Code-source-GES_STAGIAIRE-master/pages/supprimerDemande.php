<?php
    session_start();
        if(isset($_SESSION['user'])){
            
            require_once('connexiondb.php');
            $idD=isset($_GET['idD'])?$_GET['idD']:0;

            $requeteEtud="select count(*) countEtud from Etudiant where iddemande=$idD";
            $resultatEtud=$pdo->query($requeteEtud);
            $tabCountEtud=$resultatEtud->fetch();
            $nbrEtud=$tabCountEtud['countEtud'];
            
            if($nbrEtud==0){
                $requete="delete from Demande where iddemande=?";
                $params=array($idD);
                $resultat=$pdo->prepare($requete);
                $resultat->execute($params);
                header('location:Demande.php');
            }else{
                $msg="Suppression impossible: Vous devez supprimer tous les Etudiants inscris dans cette demande";
                header("location:alerte.php?message=$msg");
            }
            
         }else {
                header('location:login.php');
        }
    
    
    
    
?>
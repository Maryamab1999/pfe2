<?php
    require_once('identifier.php');
    require_once('connexiondb.php');
    
    $nomD=isset($_POST['nomD'])?$_POST['nomD']:"";
    $niveau=isset($_POST['niveau'])?strtoupper($_POST['niveau']):"";
    
    $requete="insert into Demande(nomDemande,niveau) values(?,?)";
    $params=array($nomD,$niveau);
    $resultat=$pdo->prepare($requete);
    $resultat->execute($params);
    
    header('location:Demande.php');
?>
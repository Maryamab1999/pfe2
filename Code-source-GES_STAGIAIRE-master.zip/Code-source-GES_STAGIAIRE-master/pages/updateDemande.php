<?php
    require_once('identifier.php');

    require_once('connexiondb.php');

    $idD=isset($_POST['idD'])?$_POST['idD']:0;

    $nomD=isset($_POST['nomD'])?$_POST['nomD']:"";

    $niveau=isset($_POST['niveau'])?strtoupper($_POST['niveau']):"";
    
    $requete="update Demande set nomDemande=?,niveau=? where iddemande=?";

    $params=array($nomD,$niveau,$idD);

    $resultat=$pdo->prepare($requete);

    $resultat->execute($params);
    
    header('location:Demande.php');
?>
